import siphash
import app.api.login 
import random  
import string
from collections import defaultdict

def callhash(hashkey, inval):
    inval_bytes = inval.encode('utf-8')
    return siphash.SipHash_2_4(hashkey, inval_bytes).hash()

    # return siphash.SipHash_2_4(hashkey, inval).hash()


def ht_hash(hashkey, inval, htsize):
    return callhash(hashkey, inval) % htsize

def random_string(length=10):
    letters = string.ascii_letters + string.digits
    return ''.join(random.choice(letters) for i in range(length))

#Put your collision-finding code here.
#Your function should output the colliding strings in a list.
def find_collisions(key, num_collisions=20):
    # The size of the hash table
    htsize = 2 ** 16  
    # This dictionary will store hash values and their corresponding strings
    seen_hashes = defaultdict(set)  
    # num_collisions = 20
    curr_collision = 0
    while curr_collision < num_collisions:
        potential_collision = random_string()
        hash_value = ht_hash(key, potential_collision, htsize)
        seen_hashes[hash_value].add(potential_collision)
        curr_collision = max(curr_collision, len(seen_hashes[hash_value]))
        if len(seen_hashes[hash_value]) == num_collisions: 
            return list(seen_hashes[hash_value])
    return [] # this will not get executed

#Implement this function, which takes the list of
#collisions and verifies they all have the same
#SipHash output under the given key.
def check_collisions(key, colls):
    htsize = 2 ** 16  
    first_hash = ht_hash(key, colls[0], htsize)
    for coll in colls[1:]:
        if ht_hash(key, coll, htsize) != first_hash:
            return False
    return True
        

if __name__=='__main__':
    #Look in the source code of the app to
    #find the key used for hashing.
    # key = None
    key = app.api.login.hash_key
    # print(f'key: {key}')
    colls = find_collisions(key)
    print(f'20 collision strings: {colls}')
    res = check_collisions(key, colls)
    print(f'Same SipHash output?: {res}')
